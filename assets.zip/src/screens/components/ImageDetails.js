import React from "react";
import { View, Text, StyleSheet, Image } from "react-native";

const ImageDeatil = ({imageSource, title}) => {
  copnsole.log(props);
  return (
    <View>
      <Image style={Styles.imageStyle} source={props.imageSource} />
      <Text>(props.title)</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  imageStyle: {
    height: 100,
    width: 100,
  },
});
export default ImageDeatil;
