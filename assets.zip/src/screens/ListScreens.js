import React from "react";
import { Text, StyleSheet } from "react-native";
const ListScreen = () => {
  return <Text style={styles.mytextStyle}> HI There! This is ListScreen</Text>;
};

const styles = StyleSheet.create({
  mytextStyle: {
    fontSize: 30,
  },
});
export default ListScreen;
