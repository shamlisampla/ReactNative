import React from "react";
import { Text, StyleSheet, View, Button, TouchableOpacity } from "react-native";
import { NavigationContext } from "react-navigation";
const ComponentsScreen = ({ navigation }) => {
  return (
    <View>
      <Text style={styles.mytextStyle}>
        Hi there! This is Components Screen
      </Text>
      <Button
        onPress={() => navigation.navigate("Home")}
        title="Go to components js"
      />

      <TouchableOpacity onPress={() => console.log("Touchable pressed")}>
        <Text>Go to List js</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  mytextStyle: {
    fontSize: 30,
  },
});
export default ComponentsScreen;
