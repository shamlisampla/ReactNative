import React from "react";
import { View, Text, StyleSheet } from "react-native";
import ImageDetail from "../components/ImageDetails";

const ImageScreen = () => {
  return (
    <View>
      <ImageDetails
        title="Naruto"
        imageSource={require("../../assests/naruto.jpg")}
      />
      <ImageDetails
        title="Hinata"
        imageSource={require("../../assests/naruto.jpg")}
      />
      <ImageDetails
        title="Boruto"
        imageSource={require("../../assests/naruto.jpg")}
      />
      <ImageDetails
        title="himawari"
        imageSource={require("../../assests/naruto.jpg")}
      />
    </View>
  );
};

export default ImageScreen;
